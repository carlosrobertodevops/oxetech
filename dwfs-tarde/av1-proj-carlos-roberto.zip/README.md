# Gerenciador de Tarefas — AV1 Projeto de Frontend

Aplicação web para registrar tarefas do dia a dia, organizadas por categoria. Construída com **HTML, CSS e JavaScript puro** (sem build tools) para a Avaliação 1 (AV1) da disciplina de Desenvolvimento Web Full Stack — OxeTech Academy.

## Tema escolhido

**Gerenciador de Tarefas** — cada item tem duas informações: **nome** e **categoria** (Pessoal, Trabalho, Estudo, Casa). É possível adicionar e remover tarefas dinamicamente; os dados persistem no navegador via `localStorage`.

## Funcionalidades

- 🏛️ Banner institucional de topo: Governo de Alagoas/SECTI (azul #255aa7) + OxeTech Academy (laranja #df622e)
- ➕ Adicionar tarefa com nome + categoria
- 🗑️ Remover tarefa
- ✅ Validação: campo vazio não adiciona (mostra mensagem de erro)
- 💾 Persistência automática no `localStorage` (sobrevive ao recarregar)
- 📱 Layout responsivo (mobile e desktop)

## Stack

| Camada | Tecnologia |
|---|---|
| Marcação | HTML5 semântico (`header`, `main`, `section`, `footer`) |
| Estilo | CSS3 (Flexbox + Media Query) + **Tailwind CSS** via Play CDN |
| Lógica | JavaScript vanilla (manipulação de DOM + `localStorage`) |

## Estrutura

```
projeto-final-claude/
├── index.html        # marcação semântica + grid Tailwind
├── css/
│   └── style.css     # Flexbox, paleta, tipografia, media query
├── js/
│   └── app.js        # estado, CRUD, render, persistência
├── public/
│   └── imagens/      # logos institucionais (Alagoas, OxeTech)
└── README.md
```

## Como rodar

Não requer instalação. Opções:

1. **Abrir direto:** dê duplo clique em `index.html`.
2. **Servidor local** (recomendado p/ evitar restrições de file://):
   ```bash
   python3 -m http.server 8000
   # acesse http://localhost:8000
   ```

## Como atende aos critérios (10,0 pts)

| Critério | Onde |
|---|---|
| HTML semântico (`header`/`main`/`section`/`footer`) | `index.html` |
| CSS com Flexbox + boas práticas | `css/style.css` (`.task-list`, `.task-card`) |
| Responsividade (Media Query + `flex-wrap`) | `css/style.css` (`@media min-width:768px`) |
| Framework CSS (Tailwind: componente + grid) | `index.html` (`grid grid-cols-1 md:grid-cols-2`, botões/cards) |
| Manipulação de DOM (add/remove/validação) | `js/app.js` |

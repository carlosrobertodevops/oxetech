'use strict';

let items = [];
let nextId = 1;

function init() {
  load();

  const taskForm = document.querySelector('#task-form');
  taskForm.addEventListener('submit', handleSubmit);

  const taskInput = document.querySelector('#task-input');
  taskInput.addEventListener('input', hideError);

  const taskList = document.querySelector('#task-list');
  taskList.addEventListener('click', handleRemoveClick);

  render();
}

function load() {
  try {
    const stored = localStorage.getItem('tasks');
    if (stored) {
      items = JSON.parse(stored);
      nextId = Math.max(...items.map(i => i.id), 0) + 1;
    }
  } catch (e) {
    console.error('Erro ao carregar tarefas:', e);
    items = [];
    nextId = 1;
  }
}

function save() {
  localStorage.setItem('tasks', JSON.stringify(items));
}

function validate(valor) {
  return typeof valor === 'string' && valor.trim().length > 0;
}

function hideError() {
  const errorEl = document.querySelector('#form-error');
  errorEl.classList.add('hidden');
}

function showError() {
  const errorEl = document.querySelector('#form-error');
  errorEl.textContent = 'Digite uma tarefa antes de adicionar.';
  errorEl.classList.remove('hidden');
}

function handleSubmit(e) {
  e.preventDefault();
  addItem();
}

function addItem() {
  const inputEl = document.querySelector('#task-input');
  const categoryEl = document.querySelector('#task-category');

  const nome = inputEl.value;
  const categoria = categoryEl.value;

  if (!validate(nome)) {
    showError();
    return;
  }

  hideError();

  const task = {
    id: nextId++,
    nome: nome.trim(),
    categoria: categoria
  };

  items.push(task);
  save();

  inputEl.value = '';
  categoryEl.value = 'Trabalho';

  render();
}

function removeItem(id) {
  const numId = Number(id);
  items = items.filter(item => item.id !== numId);
  save();
  render();
}

function handleRemoveClick(e) {
  const btn = e.target.closest('.btn-remove');
  if (btn) {
    const id = btn.getAttribute('data-id');
    removeItem(id);
  }
}

function render() {
  const taskList = document.querySelector('#task-list');
  const emptyState = document.querySelector('#empty-state');

  // Limpar lista
  taskList.innerHTML = '';

  // Atualizar estado vazio
  if (items.length === 0) {
    emptyState.classList.remove('hidden');
  } else {
    emptyState.classList.add('hidden');
  }

  // Recriar itens
  items.forEach(item => {
    const li = document.createElement('li');
    li.className = 'task-card';
    li.setAttribute('data-id', item.id);

    const nameSpan = document.createElement('span');
    nameSpan.className = 'task-name';
    nameSpan.textContent = item.nome;

    const categorySpan = document.createElement('span');
    categorySpan.className = 'task-category';
    categorySpan.textContent = item.categoria;

    const removeBtn = document.createElement('button');
    removeBtn.className = 'btn-remove';
    removeBtn.setAttribute('data-id', item.id);
    removeBtn.textContent = 'Remover';
    removeBtn.type = 'button';

    li.appendChild(nameSpan);
    li.appendChild(categorySpan);
    li.appendChild(removeBtn);

    taskList.appendChild(li);
  });
}

// Inicializar ao carregar a página
document.addEventListener('DOMContentLoaded', init);
